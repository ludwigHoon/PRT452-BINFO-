library(devtools)
library('RUnit')

setwd('../..')
load_all('minSNP')
setwd('./minSNP/tests')
test.suite <- defineTestSuite('Testing',
							dirs = file.path('.'),
                            testFileRegexp = '^unit.+\\.R',
							testFuncRegexp = '^test.+')

test.result <- runTestSuite(test.suite)
printTextProtocol(test.result)